class CreateFretes < ActiveRecord::Migration[7.1]
  def change
    create_table :fretes do |t|
      t.decimal :valor_total, precision: 10, scale: 2, null: false, default: 0
      t.string :status, null: false, default: "pendente"
      t.text :descricao

      t.timestamps
    end
  end
end
