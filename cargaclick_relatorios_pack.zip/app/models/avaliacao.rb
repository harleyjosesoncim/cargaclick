class Avaliacao < ApplicationRecord
  belongs_to :frete

  validates :nota, presence: true, inclusion: { in: 1..5 }
  validates :comentario, length: { maximum: 500 }
end
