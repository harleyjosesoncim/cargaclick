class Frete < ApplicationRecord
  has_many :avaliacoes, dependent: :destroy

  enum status: { pendente: "pendente", em_andamento: "em_andamento", concluido: "concluido", cancelado: "cancelado" }

  validates :valor_total, presence: true, numericality: { greater_than_or_equal_to: 0 }
end
