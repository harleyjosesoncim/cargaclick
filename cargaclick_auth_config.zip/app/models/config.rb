class Config < ApplicationRecord
end
