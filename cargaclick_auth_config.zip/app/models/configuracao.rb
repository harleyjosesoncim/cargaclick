class Configuracao < ApplicationRecord
  # Exemplo de configuração global do sistema
  # Campo: comissao_padrao:float, comissao_assinante:float
end
