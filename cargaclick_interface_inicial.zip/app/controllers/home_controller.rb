# app/controllers/home_controller.rb
class HomeController < ApplicationController
  # Tela inicial (landing page)
  def index; end

  # Sobre nós
  def about; end

  # Contato
  def contact; end

  # Fidelidade
  def fidelidade; end

  # Relatórios
  def relatorios; end
end
