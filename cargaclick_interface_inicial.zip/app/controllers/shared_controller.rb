class SharedController < ApplicationController
  def success_password
  end
end
